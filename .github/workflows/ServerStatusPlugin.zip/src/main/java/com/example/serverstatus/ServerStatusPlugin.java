package com.example.serverstatus;

import net.dv8tion.jda.api.*;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.EmbedBuilder;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import oshi.SystemInfo;
import oshi.hardware.*;
import oshi.software.os.*;

import java.awt.*;
import java.io.File;
import java.time.Instant;
import java.util.concurrent.*;

public class ServerStatusPlugin extends JavaPlugin {

    private JDA jda;
    private TextChannel channel;
    private String messageId;

    private final SystemInfo si = new SystemInfo();
    private final HardwareAbstractionLayer hw = si.getHardware();
    private final OperatingSystem os = si.getOperatingSystem();

    @Override
    public void onEnable() {
        saveDefaultConfig();

        String token = getConfig().getString("discord.token");
        String channelId = getConfig().getString("discord.channel-id");

        try {
            jda = JDABuilder.createDefault(token).build().awaitReady();
            channel = jda.getTextChannelById(channelId);
        } catch (Exception e) {
            getLogger().severe("Discord bot failed to start");
            e.printStackTrace();
            return;
        }

        channel.sendMessageEmbeds(buildEmbed()).queue(msg -> messageId = msg.getId());

        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            if (channel != null && messageId != null) {
                channel.editMessageEmbedsById(messageId, buildEmbed()).queue();
            }
        }, 0L, 80L); // 4 seconds
    }

    @Override
    public void onDisable() {
        if (jda != null) jda.shutdown();
    }

    private MessageEmbed buildEmbed() {
        CentralProcessor cpu = hw.getProcessor();
        GlobalMemory mem = hw.getMemory();
        File disk = new File(".");

        double cpuLoad = cpu.getSystemCpuLoadBetweenTicks() * 100.0;
        long usedMem = mem.getTotal() - mem.getAvailable();

        EmbedBuilder eb = new EmbedBuilder();
        eb.setTitle("Minecraft Server Status");
        eb.setColor(Bukkit.isPrimaryThread() ? Color.GREEN : Color.RED);
        eb.setTimestamp(Instant.now());

        eb.addField("Status", Bukkit.getServer().isOnline() ? "🟢 Online" : "🔴 Offline", true);
        eb.addField("Ping", Bukkit.getOnlinePlayers().stream().findFirst().map(p -> p.getPing() + " ms").orElse("N/A"), true);

        eb.addField("CPU Load", String.format("%.2f%%", cpuLoad), true);
        eb.addField("Memory",
                String.format("%.2f / %.2f GB",
                        usedMem / 1e9,
                        mem.getTotal() / 1e9),
                true);

        eb.addField("Disk",
                String.format("%.2f / %.2f GB",
                        (disk.getTotalSpace() - disk.getFreeSpace()) / 1e9,
                        disk.getTotalSpace() / 1e9),
                true);

        eb.setFooter("Auto-updated every 4 seconds");

        return eb.build();
    }
}
